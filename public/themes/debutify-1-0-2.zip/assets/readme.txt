/*========= About Theme =========*/

Theme Name: Debutify
Theme URI: https://debutify.com
Version: 1.0.3

Author: Raphael Bergeron
Privacy Policy: https://debutify.com/policies/privacy-policy
Terms & conditions: https://debutify.com/policies/terms-of-service

-------------------------------------------------------
Debutify theme, Copyright 2018 debutify.com
-------------------------------------------------------

== Installation ==

1. In your admin panel, go to Online Store > Themes and click the Upload Theme button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Action > Publish to use your new theme right away.

== Changelog ==

= BETA 1.0.0 - July 28 2018 =
* Initial BETA release

See changelog details here: https://debutify.com/pages/changelog